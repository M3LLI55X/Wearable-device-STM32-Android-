package com.example.as.doctorh;

import android.util.Log;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class UserRegister {
    public static boolean userRegister(final User1 user)
    {
        new Thread()
        {
            @Override
            public void run()
            {
                try {
                    JSONObject userJSON = new JSONObject();
                    userJSON.put("userName",user.getUsername());
                    userJSON.put("userPassword",user.getPassword());


                    //JSONObject object = new JSONObject();
                    //object.put("user",userJSON);

                    String content = String.valueOf(userJSON);

                    //HttpURLConnection connection  =
                    /**
                     * 请求地址
                     */
                    String urlPath="http://192.168.3.138:8080/20170112/login/toJsonMain.action";


                    HttpURLConnection connection = (HttpURLConnection) new URL(urlPath).openConnection();
                    //HttpURLConnection connection = (HttpURLConnection) nURL.openConnection();
                    connection.setConnectTimeout(5000);
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);
                    connection.setRequestProperty("User-Agent", "Fiddler");
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Charset", "UTF-8");
                    OutputStream os = connection.getOutputStream();
                    os.write(content.getBytes());
                    os.close();
                    /**
                     * 服务器返回结果
                     * 继续干什么事情....待续
                     */
                    InputStream inStream = connection.getInputStream();
                    int result = inStream.read();


                    Log.i("success","成功注册");

                }catch (Exception e)
                {

                }
            }
        }.start();
        return true;
    }
}
