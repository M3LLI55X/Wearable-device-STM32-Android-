package com.example.as.doctorh;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.widget.Toast;

public class register extends AppCompatActivity {
    private DBOpenHelper dbOpenHelper;  //定义DBOpenHelper,用于与数据库连接

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_register );
        //dbOpenHelper = new DBOpenHelper( register.this );
        //EditText etusername = (EditText) findViewById( R.id.username );           //获取用户名编辑框
        // EditText etage = (EditText) findViewById( R.id.age );  //获取年龄编辑框
        // EditText etpassword = (EditText) findViewById( R.id.password );           //获取密码编辑框
        //EditText etrepassword = (EditText) findViewById( R.id.repassword );  //获取确认密码编辑框

        ImageButton close = (ImageButton) findViewById( R.id.close ); //获取布局文件中的关闭按钮
        close.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                finish(); //关闭当前Activity
            }
        } );


        Button btn = (Button) findViewById( R.id.zhu_ce );//获取注册按钮
        btn.setOnClickListener( new View.OnClickListener() {  //实现将数据保存在数据库中
            @Override
            public void onClick(View v) {

                //String age = etage.getText().toString();  //获取填写的生词

                //String repassword = etrepassword.getText().toString();  //获取填写的生词

                // if (username.equals("")||password.equals("")||age.equals("")||repassword.equals("")){  //如果填写的信息为空
                //      Toast.makeText(register.this, "请将注册信息填写完整", Toast.LENGTH_SHORT).show();
                //  }else {
                // 调用insertData()方法，实现插入生词数据
                //      insertData(dbOpenHelper.getReadableDatabase(), username,age,password);
                // 显示提示信息
                //     Toast.makeText(register.this, "注册成功！", Toast.LENGTH_LONG).show();
                //   }
                EditText etusername = (EditText) findViewById( R.id.username );
                EditText etpassword = (EditText) findViewById( R.id.password );
                String username = etusername.getText().toString();  //获取填写的生词
                String password = etpassword.getText().toString();  //获取填写的生词
                User1 user = new User1();
                user.setUsername( username );
                user.setPassword( password );
                UserRegister.userRegister( user );

            }
        } );


    }

    //创建insertData()方法实现插入数据
    private void insertData(SQLiteDatabase readableDatabase, String username, String age, String password) {
        ContentValues values = new ContentValues();
        values.put( "username", username );       //保存用户名
        values.put( "password", password );//保存密码
        readableDatabase.insert( "user", null, values );//执行插入操作
    }

    //protected void onDestroy() {  //实现退出应用时，关闭数据库连接
    //    super.onDestroy();
    //     if (dbOpenHelper != null) {   //如果数据库不为空时
    //         dbOpenHelper.close();     //关闭数据库连接
    //      }
    //  }
}

