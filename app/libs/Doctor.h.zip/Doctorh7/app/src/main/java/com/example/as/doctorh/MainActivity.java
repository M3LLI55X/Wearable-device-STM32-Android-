package com.example.as.doctorh;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private DBOpenHelper dbOpenHelper;   //定义DBOpenHelper
    String name,pwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        dbOpenHelper = new DBOpenHelper( MainActivity.this );
        TextView password = (TextView) findViewById( R.id.wang_mima );   //获取布局文件中的忘记密码
        password.setOnClickListener( new View.OnClickListener() { //为忘记密码创建单击监听事件
            @Override
            public void onClick(View v) {
                //创建Intent对象
                Intent intent = new Intent( MainActivity.this, password.class );
                startActivity( intent ); //启动Activity
            }
        } );

        Button btn = (Button) findViewById( R.id.zhu_ce );//获取注册按钮
        btn.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent( MainActivity.this, register.class );
                startActivity( intent ); //启动Activity
            }
        } );


        Button butn = (Button) findViewById( R.id.deng_lu );//获取登录按钮
        //获取输入的用户信息
        butn.setOnClickListener( new View.OnClickListener() {
            public void onClick(View v) {
                //String username = ((EditText) findViewById(R.id.username)).getText().toString();
                //Bundle bundle = new Bundle();
                // bundle.putCharSequence("username", username);//保存姓名
                //Intent intent=new Intent(MainActivity.this, login.class);
                //intent.putExtras(bundle);//将Bundle对象添加到Intent对象中
                //String _username = ((EditText) findViewById(R.id.username)).getText().toString();
                //String _password = ((EditText) findViewById(R.id.password)).getText().toString();


                //User user=new User(MainActivity.this);
                //boolean flag = user.Login(_username, _password);
                //if (flag) {
                //startActivity(intent); //启动Activity
                //    } else {
                //         Toast.makeText(MainActivity.this, "登录失败！",
                //                Toast.LENGTH_SHORT).show();
                //  }

                final String username = ((EditText) findViewById( R.id.username )).getText().toString();
                final String password = ((EditText) findViewById( R.id.password )).getText().toString();
                new Thread() {
                    @Override
                    public void run() {
                        int num= init(username,password);
                        if(num>0){   //判断id是否大于1，>1就是查询到有数据 ，可以进入主界面
                            Intent it=new Intent(MainActivity.this,login.class);
                            it.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(it);
                        }else {
                            Toast.makeText (getApplicationContext(),"用户或密码错误", Toast.LENGTH_LONG ).show();
                        }
                    }


                }.start();
            }
        } );
    }

        //json格式与服务端交互
        private int init(String name,String pwd){
//  192.168.3.138 这个ip地址是电脑Ipv4 地址 /20170112 是服务端的项目名称  /login/toJsonMain 是@RequestMapping的地址
            String urlPath="http://192.168.3.138:8080/20170112/login/toJsonMain.action";
            //    String urlPath="http://192.168.42.207:8080/20170112/login/toJsonMain.action"; 这个是实体机(手机)的端口
            URL url;
            int id=0;
            try {
                url=new URL(urlPath);
                JSONObject jsonObject=new JSONObject();
                jsonObject.put("username",name);  //参数put到json串里
                jsonObject.put("password",pwd);

                //JSONObject Authorization =new JSONObject();
                //   Authorization.put("po类名",jsonObject 即po的字段)

                String content=String.valueOf(jsonObject);  //json串转string类型

                HttpURLConnection conn=(HttpURLConnection) url.openConnection(); //开启连接
                conn.setConnectTimeout(5000);

                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("ser-Agent", "Fiddler");
                conn.setRequestProperty("Content-Type","application/json");
                //写输出流，将要转的参数写入流里
                OutputStream os=conn.getOutputStream();
                os.write(content.getBytes()); //字符串写进二进流
                os.close();

                int code=conn.getResponseCode();
                if(code==200){   //与后台交互成功返回 200
                    //读取返回的json数据
                    InputStream inputStream=conn.getInputStream();
                    // 调用自己写的NetUtils() 将流转成string类型
                    String json= NetUtils.readString(inputStream);

                    Gson gson=new Gson();  //引用谷歌的json包
                    User1 user=gson.fromJson(json,User1.class); //谷歌的解析json的方法

                    id =user.getId();  //然后user.get你想要的值
                    String username=user.getUsername();
                    String password=user.getPassword();

                }else{
                    Toast.makeText (getApplicationContext(),"数据提交失败", Toast.LENGTH_LONG ).show();
                }

            }catch (Exception e){
                e.printStackTrace();
            }
            return  id;
        }





        }



