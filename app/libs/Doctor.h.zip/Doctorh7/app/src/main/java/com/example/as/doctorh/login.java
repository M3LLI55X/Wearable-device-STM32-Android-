package com.example.as.doctorh;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Intent intent = getIntent();//获取Intent对象
        Bundle bundle = intent.getExtras();//获取传递的Bundle信息
        TextView username = (TextView) findViewById(R.id.username);//获取显示姓名的TextView组件
        username.setText(bundle.getString("username"));//获取输入的姓名并显示到TextView组件中

        ImageButton close = (ImageButton) findViewById(R.id.close); //获取布局文件中的关闭按钮
        close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish(); //关闭当前Activity
            }
        });
        Button btn = (Button) findViewById(R.id.ce_shi);//获取注册按钮
        btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent intent = new Intent(login.this, mainFragment.class);
                startActivity(intent); //启动Activity

            }});
    }

}

