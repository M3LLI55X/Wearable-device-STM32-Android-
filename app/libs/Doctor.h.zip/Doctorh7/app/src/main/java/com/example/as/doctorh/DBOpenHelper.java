package com.example.as.doctorh;

        import android.database.sqlite.SQLiteOpenHelper;
        import android.database.sqlite.SQLiteDatabase;
        import android.content.Context;

public class DBOpenHelper extends SQLiteOpenHelper {

    final String CREATE_TABLE_SQL =
            "create table user(username string primary key ,age string,password string)";
    private final static String NAME = "db";
    private final static int VERSION = 1;
    public DBOpenHelper(Context context) {
        super(context,NAME, null, VERSION); //重写构造方法并设置工厂为null
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SQL); //创建用户信息表
    }
    @Override
    // 重写基类的onUpgrade()方法，以便数据库版本更新
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //提示版本更新并输出旧版本信息与新版本信息
        System.out.println("---版本更新-----" + oldVersion + "--->" + newVersion);
    }
}

