package com.example.as.doctorh;
import com.github.mikephil.charting.charts.LineChart;


import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by Administrator on 2016/2/18.
 */

public class message_fragment extends Fragment {
     LineChart chart1 ;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.message_fragment,null);

        Button btn =  view.findViewById(R.id.xx1);//获取注册按钮
       btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), message1.class);
                startActivityForResult(intent, 0x11);//启动intent对应的Activity
            }});
        return view;


    }










}



