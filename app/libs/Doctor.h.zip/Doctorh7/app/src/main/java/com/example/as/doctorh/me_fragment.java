package com.example.as.doctorh;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.widget.Button;
import android.widget.ImageView;


import androidx.annotation.Nullable;

/**
 * Created by Administrator on 2016/2/18.
 */
public class me_fragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.me_fragment, null);
        Button button = view.findViewById(R.id.btn);//获取选择头像按钮
        button.setOnClickListener(new View.OnClickListener() { //为按钮创建单机事件
            @Override
            public void onClick(View v) {
                //创建Intent对象
                Intent intent = new Intent(getActivity(), touxiang.class);
                startActivityForResult(intent, 0x11);//启动intent对应的Activity
                //Toast.LENGTH_SHORT).show(data);
            }
        });
        Button btn = view.findViewById(R.id.family);
        btn.setOnClickListener(new View.OnClickListener() { //为按钮创建单机事件
            @Override
            public void onClick(View v) {
                //创建Intent对象

                Intent intent = new Intent(getActivity(), family.class);
                startActivity(intent);
                //启动intent对应的Activity
                //Toast.LENGTH_SHORT).show(data);
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==0x11 && resultCode==0x11){	//判断是否为待处理的结果
            Bundle bundle=data.getExtras();		//获取传递的数据包
            int imageId=bundle.getInt("imageId");	//获取选择的头像ID
            ImageView iv=(ImageView)getView().findViewById(R.id.imageView);	//获取布局文件中添加的ImageView组件
            iv.setImageResource(imageId);	//显示选择的头像
        }
    }
}
